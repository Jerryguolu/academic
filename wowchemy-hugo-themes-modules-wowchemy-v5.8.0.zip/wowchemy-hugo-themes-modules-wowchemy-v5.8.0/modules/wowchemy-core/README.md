# wowchemy-core

Core Wowchemy utilities and integrations.

A module for commonalities between the `wowchemy` (Bootstrap) and `wowchemy-tailwind` (Tailwind) UIs.

## Uses

Used in the following modules:

- wowchemy-seo
- wowchemy
- wowchemy-tailwind
